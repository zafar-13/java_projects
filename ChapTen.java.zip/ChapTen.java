package edu.neu.mgen;

// Abstract class representing a generic Vehicle
abstract class Vehicle {
    String make;
    int model;

    // Constructor
    public Vehicle(String make, int model) {
        this.make = make;
        this.model = model;
    }

    // Abstract method to get the type of vehicle
    abstract String getType();

    // Common method to display information about the vehicle
    void displayInfo() {
        System.out.println("Type: " + getType());
        System.out.println("Brand: " + make);
        System.out.println("Year: " + model);
    }
}

class Car extends Vehicle {
    boolean isConvertible;

    // Constructor
    public Car(String make, int model, boolean isConvertible) {
        super (make, model);
        this.isConvertible = isConvertible;
    }

    // Implementation of the abstract method
    @Override
    String getType() {
        return "Car";
    }

    // Additional method specific to Car
    void convert() {
        System.out.println("Opening the roof!");
    }
}

class Motorbike extends Vehicle {
    boolean hasSidecar;

    // Constructor
    public Motorbike(String make, int model, boolean hasSidecar) {
        super(make, model);
        this.hasSidecar = hasSidecar;
    }

    // Implementation of the abstract method
    @Override
    String getType() {
        return "Motorbike";
    }

    // Additional method specific to Motorbike
    void honk() {
        System.out.println("Honk honk!");
    }
}

class Aircraft extends Vehicle {
    int numberOfEngines;

    // Constructor
    public Aircraft(String make, int model, int numberOfEngines) {
        super(make, model);
        this.numberOfEngines = numberOfEngines;
    }

    // Implementation of the abstract method
    @Override
    String getType() {
        return "Aircraft";
    }

    // Additional method specific to Aircraft
    void takeOff() {
        System.out.println("Taking off!");
    }
}

class Ship extends Vehicle {
    int numberOfPassengers;

    // Constructor
    public Ship(String make, int model, int numberOfPassengers) {
        super(make, model);
        this.numberOfPassengers = numberOfPassengers;
    }

    // Implementation of the abstract method
    @Override
    String getType() {
        return "Ship";
    }

    // Additional method specific to Ship
    void cruise() {
        System.out.println("Cruising on the water!");
    }
}

public class ChapTen {
    public static void main(String[] args) {
        // Creating instances of different vehicles
        Car myCar = new Car("Toyota", 2022, true);
        Motorbike myMotorbike = new Motorbike("Harley-Davidson", 2021, false);
        Aircraft myAircraft = new Aircraft("Boeing", 2020, 4);
        Ship myShip = new Ship("Cruise Liner", 2019, 2000);

        // Displaying information about each vehicle
        System.out.println("My Car:");
        myCar.displayInfo();
        myCar.convert(); // Specific method for Car
        System.out.println();

        System.out.println("My Motorbike:");
        myMotorbike.displayInfo();
        myMotorbike.honk(); // Specific method for Motorbike
        System.out.println();

        System.out.println("My Aircraft:");
        myAircraft.displayInfo();
        myAircraft.takeOff(); // Specific method for Aircraft
        System.out.println();

        System.out.println("My Ship:");
        myShip.displayInfo();
        myShip.cruise(); // Specific method for Ship
    }
}